import Foundation
import UIKit
import PlaygroundSupport
import AVFoundation

public class PlayTutorial: UIView {
    
var frameWidth = 500
var frameHeight = 800
    
var count = 3

var inhaleCount = 4
var holdCount = 7
var exhaleCount = 8
    
var timerCount = Timer()

let buttonTutorial = UIButton()
let textCountDownInhale = UILabel()
let indomieLabel = UILabel()
let textStep = UILabel()
let imageStep = UIImageView()
let playButton = UIButton()
let backgroundImage = UIImageView()
let textNameStep = UILabel()
    let okexhaleButton = UIButton()
    let textCountDown = UILabel()
    let imageMemoji = UIImageView()
    let dialogBoxImage = UIImageView()
let skipButton = UIButton()
    let inhaleTutorialLabel = UILabel()
    let okinhaleButton = UIButton()
   let okholdButton = UIButton()
    
    var instructionProcess = 0
    
    public init(scene: UIView) {
        super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }

required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
}
    
    func setupUI() {
        
        backgroundImage.image = UIImage(named: "bg.png")
        backgroundImage.frame = CGRect(x: 0, y: 0, width: 500, height: 800)
        backgroundImage.contentMode = .scaleAspectFill
        backgroundImage.alpha = 1
        self.addSubview(backgroundImage)
        
        
        dialogBoxImage.image = UIImage(named: "dialogclear.png")
        dialogBoxImage.frame = CGRect(x: 0, y: 600, width: 500, height: 100)
        dialogBoxImage.contentMode = .scaleAspectFill
        dialogBoxImage.alpha = 1
        self.addSubview(dialogBoxImage)
        
        
        inhaleTutorialLabel.text = "The first one is Inhale..."
        self.textSound(text: "The first one is Inhale" )
        inhaleTutorialLabel.numberOfLines = 3
        inhaleTutorialLabel.textColor = UIColor.black
        inhaleTutorialLabel.frame = CGRect(x: 30, y: 600, width: 500, height: 100)
        inhaleTutorialLabel.font = UIFont(name: "Arial", size: 17)
        inhaleTutorialLabel.alpha = 0
        self.addSubview(inhaleTutorialLabel)
        
        playButton.setTitle("Auto Play", for: .normal)
        playButton.backgroundColor = UIColor.black
        playButton.frame = CGRect(x: 360, y: 665, width: 100, height: 30)
        playButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        playButton.layer.cornerRadius = 14.0
        playButton.alpha = 0
        playButton.addTarget(self, action: #selector(playButtonPressed), for: .touchUpInside)
        self.addSubview(playButton)
        
        buttonTutorial.setTitle("Manual Play", for: .normal)
        buttonTutorial.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        buttonTutorial.layer.cornerRadius = 14.0
        buttonTutorial.alpha = 0
        buttonTutorial.setTitleColor(UIColor.black, for: .normal)
        buttonTutorial.backgroundColor = UIColor.white
        buttonTutorial.addTarget(self, action: #selector(playManualButtonPress), for: .touchUpInside)
        buttonTutorial.frame = CGRect(x: 180, y:665, width: 150, height: 30)
        self.addSubview(buttonTutorial)

        
        okinhaleButton.setTitle("Ok", for: .normal)
        okinhaleButton.backgroundColor = UIColor.black
        okinhaleButton.frame = CGRect(x: 360, y: 665, width: 100, height: 30)
        okinhaleButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        okinhaleButton.layer.cornerRadius = 14.0
        okinhaleButton.alpha = 0
        okinhaleButton.addTarget(self, action: #selector(okinhaleButtonPressed), for: .touchUpInside)
        self.addSubview(okinhaleButton)
        
        okholdButton.setTitle("Ok", for: .normal)
        okholdButton.backgroundColor = UIColor.black
        okholdButton.frame = CGRect(x: 360, y: 665, width: 100, height: 30)
        okholdButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        okholdButton.layer.cornerRadius = 14.0
        okholdButton.alpha = 0
        okholdButton.addTarget(self, action: #selector(okholdButtonPressed), for: .touchUpInside)
        self.addSubview(okholdButton)
        
        
        okexhaleButton.setTitle("Ok", for: .normal)
        okexhaleButton.backgroundColor = UIColor.black
        okexhaleButton.frame = CGRect(x: 360, y: 665, width: 100, height: 30)
        okexhaleButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        okexhaleButton.layer.cornerRadius = 14.0
        okexhaleButton.alpha = 0
        okexhaleButton.addTarget(self, action: #selector(okexhaleButtonPressed), for: .touchUpInside)
        self.addSubview(okexhaleButton)
        
        
        imageMemoji.image = UIImage(named: "peace.PNG")
        imageMemoji.frame = CGRect(x: 550, y: 550, width: 250, height: 250)
        imageMemoji.contentMode = .scaleAspectFit
        imageMemoji.alpha = 1
        self.addSubview(imageMemoji)
        
        
        textStep.text = "Step 1"
        textStep.textColor = UIColor.white
        textStep.frame = CGRect(x: 230, y: -340, width: frameWidth, height: frameHeight)
        textStep.font = UIFont(name: "Arial", size: 18)
        textStep.alpha = 1
        self.addSubview(textStep)
        
        textNameStep.text = "Inhale"
        textNameStep.textColor = UIColor.white
        textNameStep.frame = CGRect(x: 217, y: -300, width: frameWidth, height: frameHeight)
        textNameStep.font = UIFont(name: "Arial", size: 30)
        textNameStep.alpha = 1
        self.addSubview(textNameStep)
        

        imageStep.image = UIImage.gif(name: "inhale")
        imageStep.frame = CGRect(x: 110, y: 130, width: 300, height: 300)
        imageStep.contentMode = .scaleAspectFit
        imageStep.alpha = 1
        self.addSubview(imageStep)
        
        textCountDown.text = "\(count)"
        textCountDown.textColor = UIColor.white
        textCountDown.frame = CGRect(x: 230, y: 80, width: frameWidth, height: frameHeight)
        textCountDown.font = UIFont(name: "Arial", size: 100)
        textCountDown.alpha = 0
        self.addSubview(textCountDown)
        
        textCountDownInhale.text = "\(inhaleCount)"
        textCountDownInhale.textColor = UIColor.white
        textCountDownInhale.frame = CGRect(x: 230, y: 80, width: frameWidth, height: frameHeight)
        textCountDownInhale.font = UIFont(name: "Arial", size: 100)
        textCountDownInhale.alpha = 0
        self.addSubview(textCountDownInhale)
        
        

        animateInstruction()
    }
    
    
    func animateInstruction() {
        if(instructionProcess == 0) {
            //Animasi breath
//            UIView.animate(withDuration: 1.0,
//                           delay: 0,
//                           options: [.autoreverse, .repeat, .allowUserInteraction],
//                           animations: {
//                            self.dialogBoxImage.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
//            },
//                           completion: nil
//
//            )
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.textStep.alpha = 1
                self.textNameStep.alpha = 1
                self.inhaleTutorialLabel.alpha = 1
                self.animateCharacterOnScreen()
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2, repeats: false, block: { (time) in
                    self.instructionProcess = 1
                    self.animateInstruction()
               })
           }
        }
        if(instructionProcess == 1) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.inhaleTutorialLabel.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.inhaleTutorialLabel.alpha = 1
                
                self.inhaleTutorialLabel.text = "You should inhale for 4 seconds on one breath"
                self.textSound(text: "You should inhale for 4 seconds on one breath")
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 3, repeats: false, block: { (time) in
                    self.instructionProcess = 2
                    self.animateInstruction()
                })
            }
        }
        if(instructionProcess == 2) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.inhaleTutorialLabel.alpha = 0
                self.okinhaleButton.alpha = 1
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.inhaleTutorialLabel.alpha = 1
                
                self.inhaleTutorialLabel.text = "Lets try.."
                self.textSound(text: "Lets try")
            }, completion: nil)
            
//            { (completion) in
//                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
//                    self.instructionProcess = 3
                    
//                })
//            }
        }
        
        if(instructionProcess == 3) {
            
            self.timerCount.invalidate()
            self.count = 3
            UIView.animate(withDuration: 1, delay: 0.5, options: .curveEaseOut, animations: {
                self.okinhaleButton.alpha = 0
                self.imageMemoji.alpha = 0
                self.inhaleTutorialLabel.alpha = 0
                self.dialogBoxImage.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 0.5, options: .curveEaseOut, animations: {
                self.textSound(text: "inhale now")
//                self.inhaleTutorialLabel.alpha = 1
//                self.textCountDown.alpha = 1
//                self.textCountDown.text = "\(self.count)"
                
//                self.timerCount = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
//
                
            })
            { (completion) in
                
                Timer.scheduledTimer(withTimeInterval: 1, repeats: false, block: { (time) in
                    
                    self.instructionProcess = 4
                    self.animateInstruction()
                })
                
                
                
            }

        }
        
        if (instructionProcess == 4){
            
            print("4 disini gaes")
            
            UIView.animate(withDuration: 0, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDown.alpha = 0
                
                
            }, completion: nil)
            UIView.animate(withDuration: 0, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDownInhale.alpha = 1
                self.textCountDownInhale.text = "\(self.inhaleCount)"
                self.textSound(text: "\(self.inhaleCount)")
                Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateCountDownInhale), userInfo: nil, repeats: true)
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 4, repeats: false, block: { (time) in
                    self.instructionProcess = 5
                    
                    self.animateInstruction()
                })
                
            }

        }
        
        if (instructionProcess == 5){
            self.textNameStep.frame = CGRect(x: 225, y: -300, width: self.frameWidth, height: self.frameHeight)
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDown.alpha = 0
                self.okholdButton.alpha = 0
                self.textCountDownInhale.alpha = 0
                self.imageStep.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.inhaleTutorialLabel.alpha = 1
                self.imageStep.alpha = 1
                self.imageStep.image = UIImage.gif(name: "hold")
                self.inhaleTutorialLabel.text = "The second one is hold"
                self.textSound(text: "The second one is hold")
                self.textStep.alpha = 1
                self.textStep.text = "Step 2"
                self.textNameStep.alpha = 1
                
                self.textNameStep.text = "Hold"
                self.imageMemoji.alpha = 1
                self.dialogBoxImage.alpha = 1
            })
            {(completion) in
                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
                    self.instructionProcess = 6
                    self.animateInstruction()
                })
            }

        }
        
        if (instructionProcess == 6){
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.inhaleTutorialLabel.alpha = 0
            }, completion: nil)
            
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.inhaleTutorialLabel.alpha = 1
                self.okholdButton.alpha = 1
                
                self.inhaleTutorialLabel.text = "You should do hold in 7 seconds "
                self.textSound(text: "You should do hold in 7 seconds ")
            }, completion: nil)
//            {(completion) in
//                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
//                    self.animateInstruction()
//                })
//            }
        }
        
        if (instructionProcess == 7){
            print("7 disini gaes")
            
            self.timerCount.invalidate()
            self.count = 3
            UIView.animate(withDuration: 1, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDown.alpha = 0
                self.textCountDownInhale.alpha = 0
                self.okholdButton.alpha = 0
                self.imageMemoji.alpha = 0
                self.inhaleTutorialLabel.alpha = 0
                self.dialogBoxImage.alpha = 0

            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 0.5, options: .curveEaseOut, animations: {
                self.textSound(text: "hold now")
//                self.textCountDown.alpha = 1
//                self.textCountDown.text = "\(self.count)"
//                Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 1, repeats: false, block: { (time) in
                    self.instructionProcess = 8
                    self.animateInstruction()
                })

            }
        }
        
        if (instructionProcess == 8){
            

            print("8 disini gaes")
            
            UIView.animate(withDuration: 0, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDown.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDownInhale.alpha = 1
                self.textCountDownInhale.text = "\(self.holdCount)"
                self.textSound(text: "\(self.holdCount)")
                Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateCountDownHold), userInfo: nil, repeats: true)
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 7, repeats: false, block: { (time) in
                    self.instructionProcess = 9
                    self.animateInstruction()
                })
            }

        }
        
        if (instructionProcess == 9){
            self.textNameStep.frame = CGRect(x: 217, y: -300, width: self.frameWidth, height: self.frameHeight)
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDown.alpha = 0
                self.okholdButton.alpha = 0
                self.imageStep.alpha = 0
                self.textCountDownInhale.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.inhaleTutorialLabel.alpha = 1
                self.imageStep.alpha = 1
                self.imageStep.image = UIImage.gif(name: "exhale")
                self.inhaleTutorialLabel.text = "The Last one is Exhale"
                self.textSound(text: "The Last one is Exhale")
                self.textStep.alpha = 1
                self.textStep.text = "Step 3"
                self.textNameStep.alpha = 1
                self.textNameStep.text = "Exhale"
                self.imageMemoji.alpha = 1
                self.dialogBoxImage.alpha = 1
            })
            {(completion) in
                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
                    self.instructionProcess = 10
                    self.animateInstruction()
                })
            }

        }
        
        if (instructionProcess == 10){
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.inhaleTutorialLabel.alpha = 0
            }, completion: nil)
            
            UIView.animate(withDuration: 1.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.inhaleTutorialLabel.alpha = 1
                self.okexhaleButton.alpha = 1
                
                self.inhaleTutorialLabel.text = "You have to do the Exhale in 8 seconds on one exhalation "
                self.textSound(text: "You have to do the Exhale in 8 seconds on one exhalation")
            }, completion: nil)
//            {(completion) in
//                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
//
//                })
//            }
        }
        
        if (instructionProcess == 11){
            self.timerCount.invalidate()
            self.count = 3
            print("11 disini")
            
            UIView.animate(withDuration: 1, delay: 0, options: .curveEaseOut, animations: {
//                self.textCountDown.alpha = 0
                self.textCountDownInhale.alpha = 0
                self.okexhaleButton.alpha = 0
                self.imageMemoji.alpha = 0
                self.inhaleTutorialLabel.alpha = 0
                self.dialogBoxImage.alpha = 0

            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 0, options: .curveEaseOut, animations: {
                self.textSound(text: "exhale slowly now")
//                self.textCountDown.alpha = 1
//                self.textCountDown.text = "\(self.count)"
//                print("\(self.count)")
//                Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 1.5, repeats: false, block: { (time) in
                    self.instructionProcess = 12
                    self.animateInstruction()
                })
                
            }
        }
        
        if (instructionProcess == 12){
            

            print("12 disini gaes")
            
            UIView.animate(withDuration: 0, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDown.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDownInhale.alpha = 1
                self.textCountDownInhale.text = "\(self.exhaleCount)"
                self.textSound(text: "\(self.exhaleCount)")
                Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateCountDownExhale), userInfo: nil, repeats: true)
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 8, repeats: false, block: { (time) in
                    self.instructionProcess = 13
                    self.animateInstruction()
                })

            }

        }
        
        if(instructionProcess == 13){
            UIView.animate(withDuration: 1, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDownInhale.alpha = 0
                self.textStep.alpha = 0
                self.textNameStep.alpha = 0
                self.inhaleTutorialLabel.alpha = 0
                self.skipButton.alpha = 0
                self.imageStep.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 0.5, options: .curveEaseOut, animations: {
                self.dialogBoxImage.alpha = 1
                self.imageMemoji.alpha = 1
                self.imageMemoji.image = UIImage(named: "surprise.PNG")
                self.inhaleTutorialLabel.alpha = 1
                self.playButton.alpha = 1
                self.buttonTutorial.alpha = 1
                self.inhaleTutorialLabel.text = "Woohoo, we finish the tutorial."
                self.textSound(text: "Woohoo, we finish the tutorial.")
                Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateCountDownExhale), userInfo: nil, repeats: true)
            }, completion: nil)
//            { (completion) in
//                Timer.scheduledTimer(withTimeInterval: 8, repeats: false, block: { (time) in
//                    self.instructionProcess = 13
//                    self.animateInstruction()
//                })
//
//            }
        }
        
    
    }
    
    func animateCharacterOnScreen() {
        UIView.animate(withDuration: 1.0, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.imageMemoji.frame = CGRect(x: 310, y: 460, width: 200, height: 200)
        }))
    }
    
    @objc func playButtonPressed(sender: UIButton) {
        self.removeFromSuperview()
        self.stopBgSound()
        let unwrapView = PlayAuto(scene: self)
        PlaygroundPage.current.liveView = unwrapView
    }
    
    
    @objc func playManualButtonPress(sender: UIButton) {
        self.removeFromSuperview()
        self.stopBgSound()
        let unwrapView = PlayManual(scene: self)
        PlaygroundPage.current.liveView = unwrapView
    }
    
    
    @objc func okinhaleButtonPressed(sender: UIButton){
        
        self.instructionProcess = 3
        self.animateInstruction()
    }
    
    @objc func okholdButtonPressed(sender: UIButton){
        self.instructionProcess = 7
        self.animateInstruction()
    }
    
    @objc func okexhaleButtonPressed(sender: UIButton){
        self.instructionProcess = 11
        self.animateInstruction()
    }
    
//    @objc func update() {
//
//        if(count > 1) {
//
//            count = count - 1
//            self.textSound(text: "\(count)")
//            self.textCountDown.text = "\(count)"
//
//        }
//    }
    
    @objc func updateCountDownInhale() {
        if(inhaleCount > 1) {
            inhaleCount = inhaleCount - 1
            self.textSound(text: "\(inhaleCount)")
            self.textCountDownInhale.text = "\(inhaleCount)"
        }
    }
    
    @objc func updateCountDownHold() {
        if(holdCount > 1) {
            holdCount = holdCount - 1
            self.textSound(text: "\(holdCount)")
            self.textCountDownInhale.text = "\(holdCount)"
        }
    }
    
    @objc func updateCountDownExhale() {
        if(exhaleCount > 1) {
            exhaleCount = exhaleCount - 1
            self.textSound(text: "\(exhaleCount)")
            self.textCountDownInhale.text = "\(exhaleCount)"
        }
    }
    
    
    func textSound(text : String){
        let utterance = AVSpeechUtterance(string: "\(text)")
        utterance.voice = AVSpeechSynthesisVoice(language: "en-gb")
        utterance.rate = 0.5

        let synthesizer = AVSpeechSynthesizer()
        synthesizer.speak(utterance)
    }

}
