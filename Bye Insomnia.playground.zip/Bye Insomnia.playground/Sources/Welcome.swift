import UIKit
import PlaygroundSupport

public class Welcome : UIView{
    
    var frameWidth = 500
    var frameHeight = 800
    
    let introLabel = UILabel()
    let startButton = UIButton()
    let bannerImage = UIImageView()
    let doodleImage = UIImageView()
    let characterImage = UIImageView()
    
    public init(scene: UIView) {
        super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        doodleImage.image = UIImage(named: "bg.png")
        doodleImage.frame = CGRect(x: 0, y: 0, width: 500, height: 800)
        doodleImage.contentMode = .scaleAspectFill
        doodleImage.alpha = 1
        self.addSubview(doodleImage)
        
        introLabel.text = "BYE IMSOMNIA"
        introLabel.textColor = UIColor.white
        introLabel.frame = CGRect(x: 160, y: -280, width: frameWidth, height: frameHeight)
        introLabel.font = UIFont(name: "Arial", size: 28)
        self.addSubview(introLabel)
        
        characterImage.image = UIImage(named: "sleep.PNG")
        characterImage.frame = CGRect(x: 105, y: 200, width: 300, height: 300)
        characterImage.contentMode = .scaleToFill
        characterImage.alpha = 1
        self.addSubview(characterImage)
        
        startButton.setTitle("Start", for: .normal)
        startButton.backgroundColor = UIColor.white
        startButton.setTitleColor(UIColor.black, for: .normal)
        startButton.frame = CGRect(x: 180, y: 550, width: 150, height: 60)
        startButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 50)
        startButton.layer.cornerRadius = 14.0
        startButton.addTarget(self, action: #selector(startButtonPressed), for: .touchUpInside)
        self.addSubview(startButton)
        
        bannerImage.image = UIImage(named: "banner.png")
        bannerImage.frame = CGRect(x: 0, y: 320, width: 500, height: 200)
        bannerImage.contentMode = .scaleAspectFit
        bannerImage.alpha = 1
        self.addSubview(bannerImage)
    }
    @objc func startButtonPressed(sender: UIButton) {
        nextScreen()
    }
    
    func nextScreen() {
        self.playBgSound(volume: 1.0)
        
        self.removeFromSuperview()
        let storyOfMe = Story(scene: self)
        PlaygroundPage.current.liveView = storyOfMe
    }
    
    
}
