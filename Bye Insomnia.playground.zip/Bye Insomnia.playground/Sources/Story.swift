import Foundation
import UIKit
import PlaygroundSupport

public class Story: UIView {
    
    var frameWidth = 500
    var frameHeight = 800
    
    let introLabel = UILabel()
    
    let imageMemoji = UIImageView()
    let dialogBoxImage = UIImageView()
    let backgroundImage = UIImageView()
    let indonesiaImage = UIImageView()
    let sleepImage = UIImageView()
    let wakupImage = UIImageView()
    let cookButton = UIButton()
    
    var instructionProcess = 0
    
    public init(scene: UIView) {
        super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
    
        
        backgroundImage.image = UIImage(named: "bg.png")
        backgroundImage.frame = CGRect(x: 0, y: 0, width: 500, height: 800)
        backgroundImage.contentMode = .scaleAspectFill
        backgroundImage.alpha = 1
        self.addSubview(backgroundImage)
        
        
        dialogBoxImage.image = UIImage(named: "dialogclear.png")
        dialogBoxImage.frame = CGRect(x: 0, y: 600, width: 500, height: 100)
        dialogBoxImage.contentMode = .scaleAspectFill
        dialogBoxImage.alpha = 1
        self.addSubview(dialogBoxImage)

        
        introLabel.text = "Hi! My Name is Gilang."
        introLabel.numberOfLines = 4
        introLabel.textColor = UIColor.black
        introLabel.frame = CGRect(x: 30, y: 600, width: 500, height: 100)
        introLabel.font = UIFont(name: "Arial", size: 20)
        introLabel.alpha = 0
        self.addSubview(introLabel)
        
        imageMemoji.image = UIImage(named: "peace.PNG")
        imageMemoji.frame = CGRect(x: 550, y: 550, width: 250, height: 250)
        imageMemoji.contentMode = .scaleAspectFit
        imageMemoji.alpha = 1
        self.addSubview(imageMemoji)

        
//        wakupImage.image = UIImage(named: "ok.png")
//        wakupImage.frame = CGRect(x: 180, y: 350, width: 300, height: 300)
//        wakupImage.contentMode = .scaleAspectFit
//        wakupImage.alpha = 0
//        self.addSubview(wakupImage)
        
        cookButton.setTitle("Try Tutorial", for: .normal)
        cookButton.backgroundColor = UIColor.black
        cookButton.frame = CGRect(x: 270, y: 660, width: 200, height: 30)
        cookButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        cookButton.layer.cornerRadius = 14.0
        cookButton.alpha = 0.0
        cookButton.addTarget(self, action: #selector(playTutorialButtonPressed), for: .touchUpInside)
        self.addSubview(cookButton)
        cookButton.isHidden = true
                
        animateInstruction()
    }
    
    
    func animateInstruction() {
        if(instructionProcess == 0) {
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 1
                self.animateCharacterOnScreen()
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 1.5, repeats: false, block: { (time) in
                    self.instructionProcess = 1
                    self.animateInstruction()
                    
               })
           }
        }
        if(instructionProcess == 1) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 1
                self.introLabel.text = "I am from Indonesia."
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
                    self.instructionProcess = 2
                    self.animateInstruction()
                })
            }
        }
        if(instructionProcess == 2) {
            self.introLabel.frame = CGRect(x: 15, y: 600, width: 500, height: 100)
            self.imageMemoji.frame = CGRect(x: 310, y: 460, width: 150, height: 150)
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 0
                self.imageMemoji.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 2, delay: 0.5, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 1
                self.imageMemoji.alpha = 1
                
                self.imageMemoji.image = UIImage(named: "ohno.PNG")
                self.introLabel.text = "Sometimes I have to work overtime to do my job, but after my work is done, I can't fall asleep right away because my mind has trouble staying calm, so I can't sleep."
                self.introLabel.font = UIFont(name: "Arial", size: 17)
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 4, repeats: false, block: { (time) in
                    self.instructionProcess = 3
                    self.animateInstruction()
                })
            }
        }
        if(instructionProcess == 3) {
            self.imageMemoji.frame = CGRect(x: 310, y: 460, width: 200, height: 200)
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.introLabel.font = UIFont(name: "Arial", size: 17)
                self.introLabel.alpha = 0
                self.imageMemoji.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 1
                self.imageMemoji.alpha = 1
                self.imageMemoji.image = UIImage(named: "hmm.PNG")
                self.introLabel.text = "But....."
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 1.5, repeats: false, block: { (time) in
                    self.instructionProcess = 4
                    self.animateInstruction()
                })
            }
        }
        if(instructionProcess == 4) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 0
                self.imageMemoji.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 1
                self.imageMemoji.alpha = 1
                self.imageMemoji.image = UIImage(named: "happy.PNG")
                self.introLabel.text = "after I found a method that gave me peace of mind, I can now sleep for less than 5 minutes after doing that method.."
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false, block: { (time) in
                    self.instructionProcess = 5
                    self.animateInstruction()
                })
            }
        }
        if(instructionProcess == 5) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 0
                self.imageMemoji.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 1
                self.imageMemoji.alpha = 1
                self.imageMemoji.image = UIImage(named: "hmm.PNG")
                self.introLabel.text = "Wanna try this method with me?"
                
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2, repeats: false, block: { (time) in
                    self.instructionProcess = 6
                    self.animateInstruction()
                })
            }
        }
        
        if(instructionProcess == 6) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 0
                self.imageMemoji.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 1
                self.imageMemoji.alpha = 1
                self.imageMemoji.image = UIImage(named: "peace.PNG")
                self.introLabel.text = "This method called 4-7-8..."
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2, repeats: false, block: { (time) in
                    self.instructionProcess = 7
                    self.animateInstruction()
                })
            }
        }
        
        if(instructionProcess == 7) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 1
                self.introLabel.text = "It's mean,4 seconds inhale,7 seconds hold breath,8 seconds exhale.."
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 2, repeats: false, block: { (time) in
                    self.instructionProcess = 8
                    self.animateInstruction()
                })
            }
        }
        
        if(instructionProcess == 8) {
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 0
                self.imageMemoji.alpha = 0
                self.cookButton.isHidden = false
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.introLabel.alpha = 1
                self.imageMemoji.alpha = 1
                self.imageMemoji.image = UIImage(named: "yo.PNG")
                self.introLabel.text = "I think you ready to try this method."
                self.sleepImage.alpha = 0
                self.wakupImage.alpha = 0
                self.cookButton.alpha = 1
            })
        }
    }
    func animateCharacterOnScreen() {
        UIView.animate(withDuration: 1.0, delay: 0.5, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: UIView.AnimationOptions.curveEaseIn, animations: ({
            self.imageMemoji.frame = CGRect(x: 310, y: 460, width: 200, height: 200)
        }))
    }
    
    @objc func playTutorialButtonPressed(sender: UIButton) {
        self.stopBgSound()
        self.playBgSound(volume: 0.1)
        self.removeFromSuperview()
        let unwrapView = PlayTutorial(scene: self)
        PlaygroundPage.current.liveView = unwrapView
    }
}
