import Foundation
import UIKit
import PlaygroundSupport
import AVFoundation

public class PlayAuto: UIView {
    
var frameWidth = 500
var frameHeight = 800
    
    var count = 3
    let buttonTutorial = UIButton()
    let playButton = UIButton()
    var inhaleCount = 4
    var holdCount = 7
    var exhaleCount = 8
        
    var timerCount = Timer()
    let dialogBoxImage = UIImageView()
    let memojiImage = UIImageView()
    let textCountDownMethod = UILabel()
    let textCountDown = UILabel()
    let inhaleTutorialLabel = UILabel()
    let buttonPlayTutorial = UIButton()
let indomieLabel = UILabel()
let textStep = UILabel()
let imageStep = UIImageView()
let openButton = UIButton()
let backgroundImage = UIImageView()
let textNameStep = UILabel()
    var instructionProcess = 0
    
public init(scene: UIView) {
    super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
    setupUI()
}

required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
}
    
    func setupUI() {
        backgroundImage.image = UIImage(named: "bg.png")
        backgroundImage.frame = CGRect(x: 0, y: 0, width: 500, height: 800)
        backgroundImage.contentMode = .scaleAspectFill
        backgroundImage.alpha = 1
        self.addSubview(backgroundImage)
        
        textStep.text = "Step 1"
        textStep.textColor = UIColor.white
        textStep.frame = CGRect(x: 230, y: -340, width: frameWidth, height: frameHeight)
        textStep.font = UIFont(name: "Arial", size: 18)
        textStep.alpha = 1
        self.addSubview(textStep)
        
        textNameStep.text = "Inhale"
        textNameStep.textColor = UIColor.white
        textNameStep.frame = CGRect(x: 217, y: -300, width: frameWidth, height: frameHeight)
        textNameStep.font = UIFont(name: "Arial", size: 30)
        textNameStep.alpha = 1
        self.addSubview(textNameStep)
        
        imageStep.image = UIImage.gif(name: "inhale")
        imageStep.frame = CGRect(x: 110, y: 130, width: 300, height: 300)
        imageStep.contentMode = .scaleAspectFit
        imageStep.alpha = 1
        self.addSubview(imageStep)
        
        textCountDownMethod.text = "\(count)"
        textCountDownMethod.textColor = UIColor.white
        textCountDownMethod.frame = CGRect(x: 230, y: 0, width: frameWidth, height: frameHeight)
        textCountDownMethod.font = UIFont(name: "Arial", size: 100)
        textCountDownMethod.alpha = 0
        self.addSubview(textCountDownMethod)
        
        textCountDown.text = "\(inhaleCount)"
        textCountDown.textColor = UIColor.white
        textCountDown.frame = CGRect(x: 230, y: 80, width: frameWidth, height: frameHeight)
        textCountDown.font = UIFont(name: "Arial", size: 100)
        textCountDown.alpha = 0
        self.addSubview(textCountDown)
        
        dialogBoxImage.image = UIImage(named: "dialogclear.png")
        dialogBoxImage.frame = CGRect(x: 0, y: 600, width: 500, height: 100)
        dialogBoxImage.contentMode = .scaleAspectFill
        dialogBoxImage.alpha = 0
        self.addSubview(dialogBoxImage)
        
        
        inhaleTutorialLabel.text = "The first one is Inhale..."
        inhaleTutorialLabel.numberOfLines = 3
        inhaleTutorialLabel.textColor = UIColor.black
        inhaleTutorialLabel.frame = CGRect(x: 30, y: 600, width: 500, height: 100)
        inhaleTutorialLabel.font = UIFont(name: "Arial", size: 17)
        inhaleTutorialLabel.alpha = 0
        self.addSubview(inhaleTutorialLabel)
        
        playButton.setTitle("Auto Play", for: .normal)
        playButton.backgroundColor = UIColor.black
        playButton.frame = CGRect(x: 360, y: 665, width: 100, height: 30)
        playButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        playButton.layer.cornerRadius = 14.0
        playButton.alpha = 0
        playButton.addTarget(self, action: #selector(playButtonPressed), for: .touchUpInside)
        self.addSubview(playButton)
        
        buttonTutorial.setTitle("Manual Play", for: .normal)
        buttonTutorial.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        buttonTutorial.layer.cornerRadius = 14.0
        buttonTutorial.alpha = 0
        buttonTutorial.setTitleColor(UIColor.black, for: .normal)
        buttonTutorial.backgroundColor = UIColor.white
        buttonTutorial.addTarget(self, action: #selector(playManualPressed), for: .touchUpInside)
        buttonTutorial.frame = CGRect(x: 180, y:665, width: 150, height: 30)
        self.addSubview(buttonTutorial)
        
        buttonPlayTutorial.setTitle("Tutorial", for: .normal)
        buttonPlayTutorial.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        buttonPlayTutorial.layer.cornerRadius = 14.0
        buttonPlayTutorial.alpha = 0
        buttonPlayTutorial.setTitleColor(UIColor.black, for: .normal)
        buttonPlayTutorial.backgroundColor = UIColor.white
        buttonPlayTutorial.addTarget(self, action: #selector(playTutorial), for: .touchUpInside)
        buttonPlayTutorial.frame = CGRect(x: 320, y:10, width: 150, height: 30)
        self.addSubview(buttonPlayTutorial)
        
        memojiImage.image = UIImage(named: "surprise.PNG")
        memojiImage.frame = CGRect(x: 280, y: 410, width: 250, height: 250)
        memojiImage.contentMode = .scaleAspectFit
        memojiImage.alpha = 0
        self.addSubview(memojiImage)
        

        animateInstruction()
    }
    
    
    func animateInstruction() {
        
        if (instructionProcess == 0){
            self.textStep.alpha = 0
            self.imageStep.alpha = 0
            self.textNameStep.alpha = 0
            self.textCountDownMethod.alpha = 1

            self.textSound(text: "\(self.count)")
            self.textCountDownMethod.text = "\(self.count)"
            UIView.animate(withDuration: 1, delay: 1, options: .curveEaseOut, animations: {

                self.timerCount = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 3, repeats: false, block: { (time) in
                    self.instructionProcess = 1
                    
                    self.animateInstruction()
               })
           }
        }
        
        if (instructionProcess == 1 ){
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.textCountDownMethod.alpha = 0
                self.textStep.alpha = 1
                self.textNameStep.alpha = 1
                self.imageStep.alpha = 1
                self.textSound(text: "Inhale now")
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 0, repeats: false, block: { (time) in
                    self.instructionProcess = 2
                    
                    self.animateInstruction()
               })
           }
        }
        
        if instructionProcess == 2 {
            UIView.animate(withDuration: 0, delay: 0, options: .curveEaseOut, animations: {
                self.textStep.alpha = 1
                self.textNameStep.alpha = 1
                self.textCountDown.alpha = 1
                self.textSound(text: "\(self.inhaleCount)")
                
                self.textCountDown.text = "\(self.inhaleCount)"
                self.timerCount = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateCountDownInhale), userInfo: nil, repeats: true)
                
                
            })
            { (completion) in
                
                Timer.scheduledTimer(withTimeInterval: 4, repeats: false, block: { (time) in
                    
                    self.instructionProcess = 3
                    self.animateInstruction()
                })
                
                
                
            }
        }
        
        if instructionProcess == 3 {
            self.textNameStep.frame = CGRect(x: 225, y: -300, width: self.frameWidth, height: self.frameHeight)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.textStep.alpha = 1
                self.imageStep.alpha = 1
                self.textNameStep.alpha = 1
                
                self.imageStep.image = UIImage.gif(name: "hold")
                self.textNameStep.alpha = 1
                self.textStep.text = "Step 2"
                self.textNameStep.text = "Hold"
                self.textSound(text: "Hold now")
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 1, repeats: false, block: { (time) in
                    self.instructionProcess = 4
                    
                    self.animateInstruction()
               })
           }

        }
        
        if instructionProcess == 4 {
            
            
            
            UIView.animate(withDuration: 0, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDown.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0, delay: 0, options: .curveEaseOut, animations: {

                self.textSound(text: "\(self.holdCount)")
                self.textCountDown.alpha = 1
                self.textCountDown.text = "\(self.holdCount)"
                

                self.timerCount = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateCountDownHold), userInfo: nil, repeats: true)
                
                
            })
            { (completion) in
                
                Timer.scheduledTimer(withTimeInterval: 7, repeats: false, block: { (time) in
                    
                    self.instructionProcess = 5
                    self.animateInstruction()
                })
                
                
                
            }
        }
        
        if instructionProcess == 5{
            self.textNameStep.frame = CGRect(x: 217, y: -300, width: self.frameWidth, height: self.frameHeight)
            UIView.animate(withDuration: 0, delay: 0.5, options: .curveEaseOut, animations: {
                self.textStep.alpha = 1
                self.imageStep.alpha = 1
                self.textNameStep.alpha = 1
                self.textSound(text: "Exhale slowly now")
                self.imageStep.image =  UIImage.gif(name: "exhale")
                self.textStep.text = "Step 3"
                self.textNameStep.text = "Exhale"
            })
            { (completion) in
                Timer.scheduledTimer(withTimeInterval: 1, repeats: false, block: { (time) in
                    self.instructionProcess = 6
                    
                    self.animateInstruction()
               })
           }
        }
        
        if instructionProcess == 6{
            
            UIView.animate(withDuration: 0, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDown.alpha = 0
            }, completion: nil)
            
            UIView.animate(withDuration: 0, delay: 0, options: .curveEaseOut, animations: {
                self.textCountDown.alpha = 1
                self.textSound(text: "\(self.exhaleCount)")
                
                self.textCountDown.text = "\(self.exhaleCount)"
                self.timerCount = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateCountDownExhale), userInfo: nil, repeats: true)
                
            })
            { (completion) in
                
                Timer.scheduledTimer(withTimeInterval: 8, repeats: false, block: { (time) in
                    self.instructionProcess = 7
                    self.animateInstruction()
                })
                
                
                
            }
        }
        
        if(instructionProcess == 7){
            UIView.animate(withDuration: 1, delay: 0, options: .curveEaseOut, animations: {

                self.textStep.alpha = 0
                self.textNameStep.alpha = 0
                self.imageStep.alpha = 0
                self.textCountDown.alpha = 0
                
            }, completion: nil)
            UIView.animate(withDuration: 1, delay: 0.5, options: .curveEaseOut, animations: {
                self.dialogBoxImage.alpha = 1
                self.memojiImage.alpha = 1
                self.playButton.alpha = 1
                self.buttonPlayTutorial.alpha = 1
                self.buttonTutorial.alpha = 1
                self.inhaleTutorialLabel.alpha = 1
                self.inhaleTutorialLabel.text = "Woohoo, you did it! lets try again?"
                self.textSound(text: "Woohoo, you did it! lets try again?")
                Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateCountDownExhale), userInfo: nil, repeats: true)
            }, completion: nil)
//            { (completion) in
//                Timer.scheduledTimer(withTimeInterval: 8, repeats: false, block: { (time) in
//                    self.instructionProcess = 13
//                    self.animateInstruction()
//                })
//
//            }
        }
        
        }
    func performAnimation() {
        UIView.animate(withDuration: 0.5, delay: 1, options: .curveEaseOut, animations: {
            self.indomieLabel.isHidden = false
            self.indomieLabel.alpha = 1
        }, completion: nil)
    }
    
    

    
    @objc func update() {

        if(count > 1) {
            
            count = count - 1
            self.textSound(text: "\(count)")
            self.textCountDownMethod.text = "\(count)"
            
        }
    }
    
    @objc func updateCountDownInhale() {
        if(inhaleCount > 1) {
            inhaleCount = inhaleCount - 1
            self.textSound(text: "\(inhaleCount)")
            self.textCountDown.text = "\(inhaleCount)"
        }
    }
    
    @objc func updateCountDownHold() {
        if(holdCount > 1) {
            holdCount = holdCount - 1
            self.textSound(text: "\(holdCount)")
            self.textCountDown.text = "\(holdCount)"
        }
    }
    
    @objc func updateCountDownExhale() {
        if(exhaleCount > 1) {
            exhaleCount = exhaleCount - 1
            self.textSound(text: "\(exhaleCount)")
            self.textCountDown.text = "\(exhaleCount)"
        }
    }
    
    func textSound(text : String){
        let utterance = AVSpeechUtterance(string: "\(text)")
        utterance.voice = AVSpeechSynthesisVoice(language: "en-gb")
        utterance.rate = 0.5

        let synthesizer = AVSpeechSynthesizer()
        synthesizer.speak(utterance)
    }
    
    @objc func playButtonPressed(sender: UIButton) {
        self.removeFromSuperview()
        self.stopBgSound()
        let unwrapView = PlayAuto(scene: self)
        PlaygroundPage.current.liveView = unwrapView
    }
    
    @objc func playManualPressed(sender: UIButton) {
        self.removeFromSuperview()
        self.stopBgSound()
        let unwrapView = PlayManual(scene: self)
        PlaygroundPage.current.liveView = unwrapView
    }
    
    
    @objc func playTutorial(sender : UIButton){
        self.removeFromSuperview()
        self.playBgSound(volume: 0.1)
        let unwrapView = PlayTutorial(scene: self)
        PlaygroundPage.current.liveView = unwrapView
    }

}
