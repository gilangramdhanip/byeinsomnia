import Foundation
import UIKit
import PlaygroundSupport
import AVFoundation

public class PlayManual: UIView {
    
var frameWidth = 500
var frameHeight = 800
    
    var count = 3
    let buttonTutorial = UIButton()
    var holdButton = UILongPressGestureRecognizer()
    var inhaleCount = 5
    var holdCount = 8
    var exhaleCount = 9
 
    let uiTapButton = UIButton()
    let uiHoldButton = UIButton()
    var uiTapExhaleButton = UIButton()
    var tapExhaleButton = UITapGestureRecognizer()
    var tapButton = UITapGestureRecognizer()
    var timerCount = Timer()
    let dialogBoxImage = UIImageView()
    let memojiImage = UIImageView()
    let textCountDownMethod = UILabel()
    let textCountDown = UILabel()
    let inhaleTutorialLabel = UILabel()
    let buttonPlayTutorial = UIButton()
    
    let buttonPlayManual = UIButton()
    let buttonPlayAuto = UIButton()
let indomieLabel = UILabel()
let textStep = UILabel()
let imageStep = UIImageView()
let openButton = UIButton()
let backgroundImage = UIImageView()
let textNameStep = UILabel()
    var instructionProcess = 0
    
public init(scene: UIView) {
    super.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
    setupUI()
}

required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
}
    
    func setupUI() {
        backgroundImage.image = UIImage(named: "bg.png")
        backgroundImage.frame = CGRect(x: 0, y: 0, width: 500, height: 800)
        backgroundImage.contentMode = .scaleAspectFill
        backgroundImage.alpha = 1
        self.addSubview(backgroundImage)
        
        textStep.text = "Step 1"
        textStep.textColor = UIColor.white
        textStep.frame = CGRect(x: 230, y: -340, width: frameWidth, height: frameHeight)
        textStep.font = UIFont(name: "Arial", size: 18)
        textStep.alpha = 1
        self.addSubview(textStep)
        
        textNameStep.text = "Inhale"
        textNameStep.textColor = UIColor.white
        textNameStep.frame = CGRect(x: 217, y: -300, width: frameWidth, height: frameHeight)
        textNameStep.font = UIFont(name: "Arial", size: 30)
        textNameStep.alpha = 1
        self.addSubview(textNameStep)
        
        imageStep.image = UIImage.gif(name: "inhale")
        imageStep.frame = CGRect(x: 110, y: 130, width: 300, height: 300)
        imageStep.contentMode = .scaleAspectFit
        imageStep.alpha = 1
        self.addSubview(imageStep)
        
        textCountDownMethod.text = "\(count)"
        textCountDownMethod.textColor = UIColor.white
        textCountDownMethod.frame = CGRect(x: 230, y: 0, width: frameWidth, height: frameHeight)
        textCountDownMethod.font = UIFont(name: "Arial", size: 100)
        textCountDownMethod.alpha = 0
        self.addSubview(textCountDownMethod)
        
        textCountDown.text = "\(inhaleCount)"
        textCountDown.textColor = UIColor.white
        textCountDown.frame = CGRect(x: 230, y: 80, width: frameWidth, height: frameHeight)
        textCountDown.font = UIFont(name: "Arial", size: 100)
        textCountDown.alpha = 0
        self.addSubview(textCountDown)
        
        dialogBoxImage.image = UIImage(named: "dialogclear.png")
        dialogBoxImage.frame = CGRect(x: 0, y: 600, width: 500, height: 100)
        dialogBoxImage.contentMode = .scaleAspectFill
        dialogBoxImage.alpha = 0
        self.addSubview(dialogBoxImage)
        
        
        inhaleTutorialLabel.text = "The first one is Inhale..."
        inhaleTutorialLabel.numberOfLines = 3
        inhaleTutorialLabel.textColor = UIColor.black
        inhaleTutorialLabel.frame = CGRect(x: 30, y: 600, width: 500, height: 100)
        inhaleTutorialLabel.font = UIFont(name: "Arial", size: 17)
        inhaleTutorialLabel.alpha = 0
        self.addSubview(inhaleTutorialLabel)
        
        
        uiTapButton.setTitle("Tap", for: .normal)
        uiTapButton.backgroundColor = UIColor.white
        uiTapButton.setTitleColor(UIColor.black, for: .normal)
        uiTapButton.layer.cornerRadius = 100
        uiTapButton.frame = CGRect(x: 160, y: 450, width: 200, height: 200)
        uiTapButton.alpha = 1
        uiTapButton.titleLabel?.font = UIFont.systemFont(ofSize: 100)
        self.addSubview(uiTapButton)
        

        uiHoldButton.setTitle("Hold", for: .normal)
        uiHoldButton.backgroundColor = UIColor.white
        uiHoldButton.layer.cornerRadius = 100
        uiHoldButton.setTitleColor(UIColor.black, for: .normal)
        uiHoldButton.titleLabel?.font = UIFont.systemFont(ofSize: 100)
        uiHoldButton.frame = CGRect(x: 160, y: 450, width: 200, height: 200)
        uiHoldButton.alpha = 0
        self.addSubview(uiHoldButton)
        
        
        uiTapExhaleButton.setTitle("Tap", for: .normal)
        uiTapExhaleButton.backgroundColor = UIColor.white
        uiTapExhaleButton.layer.cornerRadius = 100
        uiTapExhaleButton.titleLabel?.font = UIFont.systemFont(ofSize: 100)
        uiTapExhaleButton.setTitleColor(UIColor.black, for: .normal)
        uiTapExhaleButton.frame = CGRect(x: 160, y: 450, width: 200, height: 200)
        uiTapExhaleButton.alpha = 0
        self.addSubview(uiTapExhaleButton)
        
        buttonPlayAuto.setTitle("Auto Play", for: .normal)
        buttonPlayAuto.frame = CGRect(x: 360, y: 665, width: 100, height: 30)
        buttonPlayAuto.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        buttonPlayAuto.layer.cornerRadius = 14.0
        buttonPlayAuto.setTitleColor(UIColor.white, for: .normal)
        buttonPlayAuto.backgroundColor = UIColor.black
        buttonPlayAuto.alpha = 0
        buttonPlayAuto.addTarget(self, action: #selector(playAuto), for: .touchUpInside)
        self.addSubview(buttonPlayAuto)
        
        buttonPlayManual.setTitle("Manual Play", for: .normal)
        buttonPlayManual.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        buttonPlayManual.layer.cornerRadius = 14.0
        buttonPlayManual.alpha = 0
        buttonPlayManual.setTitleColor(UIColor.black, for: .normal)
        buttonPlayManual.backgroundColor = UIColor.white
        buttonPlayManual.addTarget(self, action: #selector(playManual), for: .touchUpInside)
        buttonPlayManual.frame = CGRect(x: 180, y:665, width: 150, height: 30)
        self.addSubview(buttonPlayManual)
        
        buttonPlayTutorial.setTitle("Tutorial", for: .normal)
        buttonPlayTutorial.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        buttonPlayTutorial.layer.cornerRadius = 14.0
        buttonPlayTutorial.alpha = 0
        buttonPlayTutorial.setTitleColor(UIColor.black, for: .normal)
        buttonPlayTutorial.backgroundColor = UIColor.white
        buttonPlayTutorial.addTarget(self, action: #selector(playTutorial), for: .touchUpInside)
        buttonPlayTutorial.frame = CGRect(x: 320, y:10, width: 150, height: 30)
        self.addSubview(buttonPlayTutorial)
        
        
        memojiImage.image = UIImage(named: "surprise.PNG")
        memojiImage.frame = CGRect(x: 280, y: 410, width: 250, height: 250)
        memojiImage.contentMode = .scaleAspectFit
        memojiImage.alpha = 0
        self.addSubview(memojiImage)
        

        animateInstruction()
    }
    
    
    func animateInstruction() {
        
        if instructionProcess == 0 {
//            self.textSound(text: "\(inhaleCount)")
//            uiTapButton.setTitle("\(inhaleCount)", for: .normal)
            uiTapButton.alpha = 1
            tapButton = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        uiTapButton.addGestureRecognizer(tapButton)
        }
        
        if instructionProcess == 1 {
            textNameStep.frame = CGRect(x: 225, y: -300, width: self.frameWidth, height: self.frameHeight)
            textStep.text = "Step 2"
            textNameStep.text = "Hold"
            imageStep.image = UIImage.gif(name: "hold")
            uiTapButton.alpha = 0
            uiHoldButton.alpha = 1
//            self.textSound(text: "\(holdCount)")
//            uiHoldButton.setTitle("\(holdCount)", for: .normal)
            holdButton = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress))
                uiHoldButton.addGestureRecognizer(holdButton)
        }
        
        if instructionProcess == 2 {
            textNameStep.frame = CGRect(x: 217, y: -300, width: frameWidth, height: frameHeight)
            textStep.text = "Step 3"
            textNameStep.text = "Exhale"
            uiHoldButton.alpha = 0
            imageStep.image = UIImage.gif(name: "exhale")
            uiTapExhaleButton.alpha = 1
            tapExhaleButton = UITapGestureRecognizer(target: self, action: #selector(handleTapExhale))
            uiTapExhaleButton.addGestureRecognizer(tapExhaleButton)
        }
        
        if instructionProcess == 3 {
            
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseOut, animations: {
                self.uiTapExhaleButton.isHidden = true
                self.textStep.alpha = 0
                self.textNameStep.alpha = 0
                self.inhaleTutorialLabel.alpha = 0
                self.imageStep.alpha = 0
            }, completion: nil)
            UIView.animate(withDuration: 0.5, delay: 0.5, options: .curveEaseOut, animations: {
                self.dialogBoxImage.alpha = 1
                self.memojiImage.alpha = 1
                self.buttonPlayTutorial.alpha = 1
                self.buttonPlayAuto.alpha = 1
                self.buttonPlayManual.alpha = 1
                self.memojiImage.image = UIImage(named: "surprise.PNG")
                self.inhaleTutorialLabel.alpha = 1
                self.inhaleTutorialLabel.text = "Woohoo, You did it. lets try again?"
                self.textSound(text: "Woohoo, You did it. lets try again?")
            }, completion: nil)
        }
        
    }
    
    @objc func playAuto(sender: UIButton) {
        self.removeFromSuperview()
        let unwrapView = PlayAuto(scene: self)
        PlaygroundPage.current.liveView = unwrapView
    }
    
    @objc func playManual(sender: UIButton) {
        self.removeFromSuperview()
        let unwrapView = PlayManual(scene: self)
        PlaygroundPage.current.liveView = unwrapView
    }
    
    @objc func playTutorial(sender : UIButton){
        self.removeFromSuperview()
        self.playBgSound(volume: 0.1)
        let unwrapView = PlayTutorial(scene: self)
        PlaygroundPage.current.liveView = unwrapView
    }
    
    
    
    func textSound(text : String){
        let utterance = AVSpeechUtterance(string: "\(text)")
        utterance.voice = AVSpeechSynthesisVoice(language: "en-gb")
        utterance.rate = 0.5

        let synthesizer = AVSpeechSynthesizer()
        synthesizer.speak(utterance)
    }

    
    @objc func updateCountDownHold() {
        if(holdCount > 1) {
            holdCount = holdCount - 1
            self.textSound(text: "\(holdCount)")
            self.uiHoldButton.setTitle("\(holdCount)", for: .normal)
        }else if holdCount == 1 {
            self.instructionProcess = 2
            self.animateInstruction()
        }
    }
    
    // Tap action
    @objc func handleTap() {
//        if _gestureTap.state == .began{
        
        if inhaleCount > 1 {
            inhaleCount = inhaleCount - 1
            self.textSound(text: "\(inhaleCount)")
            self.uiTapButton.setTitle("\(inhaleCount)", for: .normal)
        }else if inhaleCount == 1 {
            self.instructionProcess = 1
            self.animateInstruction()
        }
        
    }
    
    @objc func handleTapExhale() {
//        if _gestureTap.state == .began{
        
        if exhaleCount > 1 {
            exhaleCount = exhaleCount - 1
            self.textSound(text: "\(exhaleCount)")
            self.uiTapExhaleButton.setTitle("\(exhaleCount)", for: .normal)
        }else if exhaleCount == 1 {
            self.instructionProcess = 3
            self.animateInstruction()
        }
        
    }
    
    @objc func handleLongPress(gesture: UILongPressGestureRecognizer) {
        // example task: show an alert
        if gesture.state == .began {
            Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateCountDownHold), userInfo: nil, repeats: true)
        }
    }
    
    

}
