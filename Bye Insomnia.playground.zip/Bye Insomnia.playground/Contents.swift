//BYE INSOMNIA
// THIS PLAYGROUND MADE BASED ON MY TRUE STORY ABOUT MY EXPERIENCE OVERCOMING INSOMNIA.

import UIKit
import PlaygroundSupport

var view = UIView()
var welcomeView = Welcome(scene: view)

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = welcomeView
